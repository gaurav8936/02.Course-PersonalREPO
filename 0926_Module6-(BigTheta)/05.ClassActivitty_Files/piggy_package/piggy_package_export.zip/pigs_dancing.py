def dance():
	print("Traa la laaa!")
	
def jig():
	print("What do I look like, a human?  Pigs don't jig.")