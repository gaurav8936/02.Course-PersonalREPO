def march(x):
	print("March to the " + str(x) + "beat!")
	
	
def catch():
	print("You can't catch this pig!!!!")