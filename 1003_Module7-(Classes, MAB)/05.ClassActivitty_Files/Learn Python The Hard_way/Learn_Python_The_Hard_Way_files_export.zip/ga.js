<!DOCTYPE html>
<html lang="en">
<!-- __ _ _ _ __| |_ (_)__ _____
    / _` | '_/ _| ' \| |\ V / -_)
    \__,_|_| \__|_||_|_| \_/\___| -->
  <head><script type="text/javascript" src="/static/js/analytics.js?v=1518460053.0" charset="utf-8"></script>

<script type="text/javascript">archive_analytics.values.service='wb';archive_analytics.values.server_name='wwwb-app22.us.archive.org';archive_analytics.values.server_ms=1184;</script><script type="text/javascript" src="/static/js/wbhack.js?v=1518460053.0" charset="utf-8"></script>

<script type="text/javascript">
__wbhack.init('http://web.archive.org/web');
</script>
<link rel="stylesheet" type="text/css" href="/static/css/banner-styles.css?v=1518460053.0" />
<link rel="stylesheet" type="text/css" href="/static/css/iconochive.css?v=1518460053.0" />

<!-- End Wayback Rewrite JS Include -->
    <title>Item not available</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link href="//web.archive.org/web/20171009123630cs_/http://archive.org/includes/archive.min.css?v=66127" rel="stylesheet" type="text/css"/>
    <link rel="SHORTCUT ICON" href="/web/20171009123630im_/http://www/images/glogo.jpg"/>
  </head>
  <body class="navia">

    <!-- Wraps all page content -->
    <div id="wrap">


      <div class="navbar navbar-inverse navbar-static-top" role="navigation">
        <div id="nav-tophat-helper" class="hidden-xs"></div>
        <ul class="nav navbar-nav">
          <li class="dropdown dropdown-ia pull-left">
            <a title="Web" class="navia-link web" href="http://web.archive.org/web/20171009123630/https://archive.org/web/"><span class="iconochive-web"></span></a>
          </li>
          <li class="dropdown dropdown-ia pull-left">
            <a title="Texts" class="navia-link texts" href="http://web.archive.org/web/20171009123630/https://archive.org/details/texts"><span class="iconochive-texts"></span></a>
          </li>
          <li class="dropdown dropdown-ia pull-left">
            <a title="Video" class="navia-link movies" href="http://web.archive.org/web/20171009123630/https://archive.org/details/movies"><span class="iconochive-movies"></span></a>
          </li>
          <li class="dropdown dropdown-ia pull-left">
            <a title="Audio" class="navia-link audio" href="http://web.archive.org/web/20171009123630/https://archive.org/details/audio"><span class="iconochive-audio"></span></a>
          </li>
          <li class="dropdown dropdown-ia pull-left">
            <a title="Software" class="navia-link software" href="http://web.archive.org/web/20171009123630/https://archive.org/details/software"><span class="iconochive-software"></span></a>
          </li>
          <li class="dropdown dropdown-ia pull-left rightmost">
            <a title="Image" class="navia-link image" href="http://web.archive.org/web/20171009123630/https://archive.org/details/image"><span class="iconochive-image"></span></a>
          </li>

          <li class="navbar-brand-li"><a class="navbar-brand" href="http://web.archive.org/web/20171009123630/https://archive.org/" target="_top" title="Welcome to Internet Archive"><span class="iconochive-logo"></span></a></li>

          <li class="nav-hamburger dropdown dropdown-ia pull-right hidden-sm hidden-md hidden-lg">
            <div class="container-fluid">
              <div class="navbar-header">
                <a href="http://web.archive.org/web/20171009123630/https://archive.org/about/" class="button navbar-toggle collapsed" data-toggle="collapse" aria-expanded="false">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                </a>
              </div>
            </div>
          </li>

          <li id="nav-search" class="dropdown dropdown-ia pull-right">
            <a href="http://web.archive.org/web/20171009123630/https://archive.org/search.php"><span class="iconochive-search"></span></a>
            <div>
              <form method="post" role="search" action="http://web.archive.org/web/20171009123630/https://archive.org/searchresults.php" target="_top">
                <label for="search-bar-2" class="sr-only">Search the Archive</label>
                <input id="search-bar-2" placeholder="Search" type="text" name="search"/>
                <input type="submit" value="Search"/>
              </form>
            </div>
          </li>

          <li class="dropdown dropdown-ia pull-right">
            <a href="http://web.archive.org/web/20171009123630/https://archive.org/donate" _target="top" data-toggle="tooltip" data-placement="bottom" title="Donate"><img id="glyphme" src="http://web.archive.org/web/20171009123630im_/https://archive.org/images/gift.png"></a>
          </li>

          <li class="dropdown dropdown-ia pull-right">
            <a href="http://web.archive.org/web/20171009123630/https://archive.org/create" style="padding-left:0" _target="top" title="Upload"><span class="iconochive-upload"></span></a>
          </li>

        </ul>
      </div><!--/.navbar-->



      <!-- Begin page content -->
      <div class="container container-ia">
        <a href="#maincontent" class="hidden-for-screen-readers">Skip to main content</a>


        <h1>Item not available</h1>
        The item is not available due to issues with the item's content.


      </div><!--/.container-->
    </div><!--/#wrap-->
  </body>
</html>
